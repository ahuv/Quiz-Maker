# Quiz-Maker
Computer Methodology Term Project

This program creates a system which allows a Teacher user to create a quiz file, and a Student user to take the quiz and receive a grade.


