package Quiz;


public class DuplicateQuizNameException extends Exception {
	
	public DuplicateQuizNameException(String message)
	{
		super(message);
	}

}
