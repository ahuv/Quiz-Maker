package Quiz;


public class EmptyLineException extends Exception {
	
	public EmptyLineException()
	{
		super();
	}
	
	public EmptyLineException(String message)
	{
		super(message);
	}

}