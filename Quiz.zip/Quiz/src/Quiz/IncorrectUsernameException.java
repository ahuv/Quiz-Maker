package Quiz;


public class IncorrectUsernameException extends Exception
{

	public IncorrectUsernameException()
	{
		super();
	}

	public IncorrectUsernameException(String message)
	{
		super(message);
	}

}
